import java.util.ArrayList;

// This class handles all messages-related operations
public class MessageManager {
    private final ArrayList<Message> messages = new ArrayList<>();

    // A method for sending a new message
    public void sendMessage(String text, String sender, String receiver) {
        if (text.isEmpty()) {
            System.out.println("Error: Message cannot be empty.");
            return;
        }
        Message msg = new Message(text, sender, receiver);
        msg.markSent();
        messages.add(msg);
        System.out.println("Message sent successfully!");
    }

    // A method to retrieve messages for a specific user 
    public void receiveMessages(String receiver) {
        boolean found = false;
        for (Message m : messages) {
            if (m.getReceiver().equalsIgnoreCase(receiver)) {
                m.markReceived();
                System.out.println("\n" + m);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No new messages for " + receiver);
        }
    }

    // a method to mark all messages for a user as read 
    public void readMessages(String receiver) {
        boolean hasUnread = false;
        for (Message m : messages) {
            if (m.getReceiver().equalsIgnoreCase(receiver) && !m.isRead()) {
                m.markRead();
                hasUnread = true;
            }
        }
        if (hasUnread) {
            System.out.println("All your messages have been marked as read.");
        } else {
            System.out.println("No unread messages to mark as read.");
        }
    }
}
