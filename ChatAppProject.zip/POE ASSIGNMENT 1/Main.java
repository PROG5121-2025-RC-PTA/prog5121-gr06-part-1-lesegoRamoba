import java.util.Scanner;

// Main class that runs the Chat App and handles user input
public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in) //  gets input from the user
        ) {
            MessageManager manager = new MessageManager();  // Create a message manager object
            int choice;  // To store user menu choices
            // Menu loop
            do {
                System.out.println("\n--- Chat App ---");
                System.out.println("1. Send Message");
                System.out.println("2. View Messages");
                System.out.println("3. Mark Messages as Read");
//            System.out.println("4. Exit");
System.out.print("Enter your choice: ");
choice = scanner.nextInt();  
scanner.nextLine();  // Clear buffer

switch (choice) {
    case 1 ->       {
        // Send message
        System.out.print("Sender Name: ");
        String sender = scanner.nextLine();
        System.out.print("Receiver Name: ");
        String receiver = scanner.nextLine();
        System.out.print("Message Text: ");
        String text = scanner.nextLine();
        manager.sendMessage(text, sender, receiver);
                    }
        
    case 2 ->       {
        // View messages for a receiver
        System.out.print("Enter your name to view messages: ");
        String viewer = scanner.nextLine();
        manager.receiveMessages(viewer);
                    }
        
    case 3 ->       {
        // Mark messages as read
        System.out.print("Enter your name to mark messages as read: ");
        String reader = scanner.nextLine();
        manager.readMessages(reader);
                    }
        
    case 4 -> // Exit
        System.out.println("Exiting Chat App. Goodbye!");
        
    default -> System.out.println("Invalid choice. Please enter 1-4.");
}
            } while (choice != 4); // Loop until the user chooses to exit
            // Close scanner
        } // Create a message manager object
    }
}
