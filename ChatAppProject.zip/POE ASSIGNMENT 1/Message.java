/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
public class Message {
    private final String payload;
    private final String sender;
    private final String receiver;
    private boolean isSent;
    private boolean isReceived;
    private boolean isRead;

    public Message(String payload, String sender, String receiver) {
        this.payload = payload;
        this.sender = sender;
        this.receiver = receiver;
        this.isSent = false;
        this.isReceived = false;
        this.isRead = false;
    }

    public String getPayload() { return payload; }
    public String getSender() { return sender; }
    public String getReceiver() { return receiver; }

    public boolean isSent() { return isSent; }
    public boolean isReceived() { return isReceived; }
    public boolean isRead() { return isRead; }

    public void markSent() { this.isSent = true; }
    public void markReceived() { this.isReceived = true; }
    public void markRead() { this.isRead = true; }

    @Override
    public String toString() {
        return "From: " + sender + " -> To: " + receiver + "\n" +
               "Message: " + payload + "\n" +
               "Sent: " + isSent + ", Received: " + isReceived + ", Read: " + isRead;
    }
}
